import { Routes } from '@angular/router';
import { RegistroComponent } from './pages/registro/registro.component';
import { TendenciasComponent } from './pages/tendencias/tendencias.component';

export const routes: Routes = [
  { path: '', component: TendenciasComponent }, // Página de inicio
  { path: 'registro', component: RegistroComponent }, // Página de registro
  { path: 'tendencias', component: TendenciasComponent }, // Página de tendencias
  { path: '**', redirectTo: '' } // Redirección si la ruta no existe
];
