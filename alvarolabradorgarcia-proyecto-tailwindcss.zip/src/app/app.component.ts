import { Component, OnInit, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { RouterOutlet, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterOutlet], 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'] // Corrección de styleUrl → styleUrls
})
export class AppComponent implements OnInit {
  title = 'alvarolabradorgarcia-proyecto-tailwindcss';
  
  isMenuOpen = false; 
  isDarkMode = false; 

  constructor(private renderer: Renderer2) {} // Inyección de Renderer2

  ngOnInit() {
    this.loadTheme();
  }

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    this.applyTheme(this.isDarkMode);
    localStorage.setItem('theme', this.isDarkMode ? 'dark' : 'light');
  }

  loadTheme() {
    const storedTheme = localStorage.getItem('theme');
    this.isDarkMode = storedTheme === 'dark' || (!storedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches);
    this.applyTheme(this.isDarkMode);
  }

  applyTheme(isDark: boolean) {
    if (isDark) {
      this.renderer.addClass(document.documentElement, 'dark');
    } else {
      this.renderer.removeClass(document.documentElement, 'dark');
    }
  }
}
